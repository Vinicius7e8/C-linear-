﻿using ConsoleApp2;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ConsoleApp2
{
    public class Gerenciador
    {
        private List<Estoquedeitens> itens;

        public Gerenciador()
        {
            itens = new List<Estoquedeitens>();
        }

        public void AdicionarItem(string nome, string tipo, decimal valor, int estoque)
        {
            var item = itens.FirstOrDefault(i => i.Nome == nome);
            if (item == null)
            {
                itens.Add(new Estoquedeitens(nome, tipo, valor, estoque));
            }
            else
            {
                item.Adicionar(estoque);
            }
        }

        public bool RemoverItem(string nome)
        {
            var item = itens.FirstOrDefault(i => i.Nome == nome);
            if (item != null)
            {
                itens.Remove(item);
                return true;
            }
            return false;
        }
    

        public void MostrarEstoque()
        {
            foreach (var item in itens)
            {
                Console.WriteLine($"Item: {item.Nome} ");
                Console.WriteLine($"Tipo: {item.Tipo}");
                Console.WriteLine($"Valor: {item.Valor:c2}");
                Console.WriteLine($"Estoque: {item.Estoque}");
                Console.WriteLine("");
            }
        }

        internal void AdicionarItem(string v1, string v2, double v3)
        {
            throw new NotImplementedException();
        }
    }
}