﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    public class Estoquedeitens
    {
        public string Nome { get; set; }
        public string Tipo { get; set; }
        public decimal Valor { get; set; }
        public int Estoque { get; set; }


        public Estoquedeitens(string nome, string tipo, decimal valor, int estoque)
        {
            Nome = nome;
            Tipo = tipo;
            Valor = valor;
            Estoque = estoque;
        }

        public Estoquedeitens()
        {
        }

        public Estoquedeitens(string Nome, string Tipo, decimal Valor, object value, int estoque)
        {
        }


        public void Adicionar(int estoque)
        {
            Estoque += estoque;
        }

        public bool Remover(int estoque)
        {
            if (estoque > Estoque)
            {
                return false;
            }
            Estoque -= estoque;
            return true;
        }
    }
}
    
