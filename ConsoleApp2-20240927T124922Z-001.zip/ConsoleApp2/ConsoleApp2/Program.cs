﻿using System;
using ConsoleApp2;


public class Program
{
    
    public static void Main(string[] args)
    {
        var gerenciadorEstoque = new Gerenciador();

        var ntitulo = new Titulo();


        // Adicionando 50 itens ao estoque
      
        gerenciadorEstoque.AdicionarItem("Processador Intel Core i7-10700K", "Processador", 530.40m, 15);
        gerenciadorEstoque.AdicionarItem("Memória RAM Corsair Vengeance LPX 16GB (2x8GB)", "Memória RAM", 89.99m, 20);
        gerenciadorEstoque.AdicionarItem("SSD Western Digital Blue SN550 1TB", "SSD", 104.99m, 25);
        gerenciadorEstoque.AdicionarItem("Placa-Mãe ASUS ROG Strix B450-F Gaming", "Placa-Mãe", 119.99m, 30);
        gerenciadorEstoque.AdicionarItem("Monitor Dell UltraSharp U2719D 27\"", "Monitor", 349.99m, 35);
        gerenciadorEstoque.AdicionarItem("Teclado Mecânico Corsair K70 RGB MK.2", "Teclado", 139.99m, 40);
        gerenciadorEstoque.AdicionarItem("Mouse Logitech G502 HERO", "Mouse", 79.99m, 45);
        gerenciadorEstoque.AdicionarItem("Headset HyperX Cloud II", "Headset", 99.99m, 50);
        gerenciadorEstoque.AdicionarItem("Fonte de Alimentação EVGA 600 W", "Fonte de Alimentação", 54.99m, 55);
        gerenciadorEstoque.AdicionarItem("Gabinete Cooler Master MasterBox MB511", "Gabinete", 69.99m, 60);
        gerenciadorEstoque.AdicionarItem("Cooler CPU Cooler Master Hyper 212 RGB", "Cooler CPU", 39.99m, 65);
        gerenciadorEstoque.AdicionarItem("Placa de Captura Elgato Game Capture HD60 S", "Placa de Captura", 179.99m, 70);
        gerenciadorEstoque.AdicionarItem("Webcam Logitech C920 HD Pro", "Webcam", 79.99m, 75);
        gerenciadorEstoque.AdicionarItem("Cadeira Gamer Cougar Armor S Royal", "Cadeira Gamer", 249.99m, 80);
        gerenciadorEstoque.AdicionarItem("Mousepad Corsair MM800 RGB Polaris", "Mousepad", 59.99m, 85);
        gerenciadorEstoque.AdicionarItem("Caixa de Som Bluetooth JBL Charge 4", "Caixa de Som", 179.99m, 90);
        gerenciadorEstoque.AdicionarItem("Roteador Wi-Fi TP-Link Archer C6", "Roteador", 49.99m, 95);
        gerenciadorEstoque.AdicionarItem("Hub USB Anker 10 Portas", "Hub USB", 29.99m, 100);
        gerenciadorEstoque.AdicionarItem("Suporte para Notebook Nootle DigiPro", "Suporte para Notebook", 19.99m, 105);
        gerenciadorEstoque.AdicionarItem("Pasta Térmica Cooler Master MasterGel Maker", "Pasta Térmica", 9.99m, 110);
        gerenciadorEstoque.AdicionarItem("Adaptador Bluetooth USB Avantree DG40S", "Adaptador Bluetooth", 14.99m, 115);
        gerenciadorEstoque.AdicionarItem("Cabo HDMI 2.0 Ultra HD 4K", "Cabo HDMI", 7.99m, 120);
        gerenciadorEstoque.AdicionarItem("Adaptador DVI para VGA", "Adaptador", 3.99m, 125);
        gerenciadorEstoque.AdicionarItem("Case para HD Externo SATA III USB 3.0", "Case para HD", 12.99m, 130);
        gerenciadorEstoque.AdicionarItem("Estabilizador SMS Revolution Speedy 300VA", "Estabilizador", 39.99m, 135);
        gerenciadorEstoque.AdicionarItem("Filtro de Linha Clamper Multiproteção 8 Tomadas", "Filtro de Linha", 29.99m, 140);
        gerenciadorEstoque.AdicionarItem("Placa de Rede Gigabit TP-Link TG-3468", "Placa de Rede", 19.99m, 145);
        gerenciadorEstoque.AdicionarItem("Hub Ethernet USB 3.0 Ugreen", "Hub Ethernet", 24.99m, 150);
        gerenciadorEstoque.AdicionarItem("Cabo de Rede Cat6 UTP 10m", "Cabo de Rede", 8.99m, 155);
        gerenciadorEstoque.AdicionarItem("Repetidor de Sinal Wi-Fi TP-Link RE450 AC1750", "Repetidor de Sinal Wi-Fi", 69.99m, 160);
        gerenciadorEstoque.AdicionarItem("Switch TP-Link de 8 Portas Gigabit", "Switch", 29.99m, 165);
        gerenciadorEstoque.AdicionarItem("Antena Wi-Fi Externa Intelbras Omni 15dBi", "Antena Wi-Fi", 39.99m, 170);
        gerenciadorEstoque.AdicionarItem("Câmera de Segurança Intelbras Multi HD 720p", "Câmera de Segurança", 89.99m, 175);
        gerenciadorEstoque.AdicionarItem("Gravador de DVD Externo LG", "Gravador de DVD", 24.99m, 180);
        gerenciadorEstoque.AdicionarItem("Leitor de Cartão de Memória SanDisk USB 3.0", "Leitor de Cartão de Memória", 14.99m, 185);
        gerenciadorEstoque.AdicionarItem("Microfone de Lapela Boya BY-M1", "Microfone de Lapela", 19.99m, 190);
        gerenciadorEstoque.AdicionarItem("Fone de Ouvido Bluetooth Sony WH-CH510", "Fone de Ouvido Bluetooth", 49.99m, 195);
        gerenciadorEstoque.AdicionarItem("Suporte para Celular GoPro Shorty", "Suporte para Celular", 24.99m, 200);
        gerenciadorEstoque.AdicionarItem("Carregador Portátil Anker PowerCore 10000mAh", "Carregador Portátil", 29.99m, 205);
        gerenciadorEstoque.AdicionarItem("Cabo Lightning MFi Certificado Apple", "Cabo Lightning",29.99m, 210);
        gerenciadorEstoque.AdicionarItem("Capa para iPhone 12 Pro Max", "Capa para Celular", 14.99m, 215);
        gerenciadorEstoque.AdicionarItem("Película de Vidro Temperado para Samsung Galaxy S21 Ultra", "Película de Vidro", 9.99m, 220);
        gerenciadorEstoque.AdicionarItem("Cabo USB-C para USB-C Anker Powerline+ 100W", "Cabo USB-C", 19.99m, 225);
        gerenciadorEstoque.AdicionarItem("Cabo Micro USB Anker Powerline+ 3ft", "Cabo Micro USB", 7.99m, 230);
        gerenciadorEstoque.AdicionarItem("Carregador Veicular Anker PowerDrive 2", "Carregador Veicular", 12.99m, 235);
        gerenciadorEstoque.AdicionarItem("Adaptador de Tomada Universal Mibao", "Adaptador de Tomada", 7.99m, 240);
        gerenciadorEstoque.AdicionarItem("Hub USB-C Ugreen 5-em-1", "Hub USB-C", 19.99m, 245);
        gerenciadorEstoque.AdicionarItem("Suporte Veicular para Celular Ugreen", "Suporte Veicular", 9.99m, 250);
        gerenciadorEstoque.AdicionarItem("Carregador Sem Fio Anker PowerWave Pad", "Carregador Sem Fio", 14.99m, 255);
        gerenciadorEstoque.AdicionarItem("Bateria Externa Aukey 20000mAh", "Bateria Externa", 29.99m, 260);
        gerenciadorEstoque.AdicionarItem("Lâmpada Inteligente Wi-Fi TP-Link LB100", "Lâmpada Inteligente", 19.99m, 265);
        gerenciadorEstoque.AdicionarItem("Sensor de Movimento Xiaomi Mi Smart Sensor Set", "Sensor de Movimento", 24.99m, 270);
        gerenciadorEstoque.AdicionarItem("Termostato Inteligente Tado° V3+", "Termostato Inteligente", 129.99m, 275);
        gerenciadorEstoque.AdicionarItem("Câmera de Ação GoPro HERO9 Black", "Câmera de Ação", 349.99m, 280);
        gerenciadorEstoque.AdicionarItem("Ring Light Neewer 18\" com Tripé", "Ring Light", 49.99m, 285);
        gerenciadorEstoque.AdicionarItem("Tripé de Vídeo Manfrotto MVK502055XPRO3", "Tripé de Vídeo", 329.99m, 290);
        gerenciadorEstoque.AdicionarItem("Estabilizador de Imagem DJI Ronin-S", "Estabilizador de Imagem", 549.99m, 295);
        gerenciadorEstoque.AdicionarItem("Microfone Condensador Rode NT1-A", "Microfone Condensador", 229.99m, 300);
        

            string cadastro = "0";
            string senhaCadastro = "0";
            string conttadors = "0";
            int contador;
            int.TryParse(conttadors.ToString(), out contador);


           
            String sairMenu = "1";
            while (sairMenu != "sair")
            {   
                Console.Clear();
                ntitulo.titulo();
                Console.WriteLine("                       Login");
                Console.WriteLine("Escolha um dos numeros correspondentes uma das opções, correspondentes");
                Console.WriteLine("1)não tenho cadatros");
                Console.WriteLine("2)já tenho cadatros");
                Console.WriteLine("3)sair");
                String escolhaMenu = Console.ReadLine();

                String senhaComcluida = "0";



                if (escolhaMenu == "1")
                {


                    while (senhaComcluida != "sair")
                    {

                        Console.WriteLine("_________");
                        Console.WriteLine("");
                        Console.Write("Digite seu nome: ");
                        cadastro = Console.ReadLine();
                        Console.Write("Digite sua senha: ");
                        senhaCadastro = Console.ReadLine();

                        if (senhaCadastro.Length >= 8 && cadastro.Length >= 3)
                        {
                            Console.WriteLine("Cadastro Comcluido");
                            senhaComcluida = "sair";
                        }
                        else
                        {
                            Console.WriteLine("Senha ou usuario invalidos. certifique-se que a senha tenha mais de 7 digitos e o usuraio mais que 3 digitos tente novamente");
                        }

                    }
                }
                else if (escolhaMenu == "2")
                {
                    string segurança = "0";
                    while (segurança != "sair")
                    {
                        Console.Clear();
                        
                        Console.WriteLine("");
                        Console.WriteLine("");
                        Console.WriteLine("                       Login");
                        Console.WriteLine("");
                        Console.Write("usuario: ");
                        string usuario = Console.ReadLine();
                        Console.Write("senha: ");
                        string senhaUsuario = Console.ReadLine();

                        if (usuario == cadastro && senhaUsuario == senhaCadastro)
                        {
                            Console.WriteLine("Usuraio e senha confirmado");
                            string sairSubmenu = "1";
                            Console.ReadLine();
                            while (sairSubmenu != "sair")
                            {
                                Console.Clear();
                                ntitulo.titulo();
                                Console.WriteLine("");
                                Console.WriteLine("");
                                Console.WriteLine("Olá " + usuario + " sejá bem vindo ao menu de interação");
                                Console.WriteLine("Escolha uma opção para iniciar uma interação");
                                Console.WriteLine("1) lista de produtos");
                                Console.WriteLine("2) deletar produto?");
                                Console.WriteLine("3) adicionar produto");
                                Console.WriteLine("4) sair");
                                String supMenu = Console.ReadLine();

                                switch (supMenu)
                                {
                                    case "1":
                                      Console.Clear();
                                      string sair1 = "1";
                                      ntitulo.titulo();
                                      Console.WriteLine("");
                                      Console.WriteLine("Estoque inicial:");
                                      gerenciadorEstoque.MostrarEstoque();
                                      Console.ReadLine();                                      
                                    break;
                                    case "2":
                                        Console.Clear();
                                        string sair2 = "2";
                                        while (sair2 != "1")
                                        {
                                            ntitulo.titulo();
                                            Console.WriteLine("");
                                            Console.WriteLine("digite o nome do item que deseja excluir");
                                            gerenciadorEstoque.RemoverItem(Console.ReadLine());
                                            Console.WriteLine("Digite 1 para sair ou digique qualquer letra para continuar");
                                            sair2 = Console.ReadLine();
                                        }
                                    break;

                                    case "3":
                                        Console.Clear();
                                        string sair3 = "2";
                                        while (sair3 != "1")
                                        {
                                            ntitulo.titulo();
                                            Console.WriteLine("");
                                            Console.WriteLine("Dite o nome do produto, o tipo do produto, o valor do produto e quantidade em estoque em sequencia");
                                            
                                            gerenciadorEstoque.AdicionarItem(Console.ReadLine(), Console.ReadLine(), decimal.Parse(Console.ReadLine()), int.Parse(Console.ReadLine()) );
                                            Console.WriteLine("Digite 1 para sair ou aperte enter para comtinuar");
                                            sair3 = Console.ReadLine();
                                             
                                        }                                 
                                        break;
                                    case "4":
                                        Console.WriteLine("Fim do sistema");
                                        sairSubmenu = "sair";
                                        segurança = "sair";
                                        sairMenu = "sair";
                                    break;
                                    default:
                                        Console.WriteLine("opção invalida");
                                        break;
                                }
                            }
                        }
                        else
                        {
                            Console.WriteLine("Senha incorreta" + contador);
                            contador = contador + 1;
                            if (contador == 3)
                            {
                                Console.WriteLine("Usuario bloqueado");

                                segurança = "sair";
                                sairMenu = "sair";
                            }
                        }
                    }
                }
                else if (escolhaMenu == "3")
                {
                    Console.WriteLine("fim do sistema");
                    sairMenu = "sair";

                }
                else
                {
                    Console.WriteLine("comando invalido ");
                }
            }
    }
}

